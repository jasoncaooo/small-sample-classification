# Extension 4 reproduction — 2026-11-28

Use Python 3.12. Obtain the competition ZIP yourself; it must contain train.csv at its root. No data, predictions, private row-ID audits or local absolute-path records are included.

From the extracted bundle root:

```bash
python -m pip install -r Extension4/requirements_2026-11-28.txt
python Extension4/feature_stability_2026-11-25_v2.py --zip /path/to/small-sample-classification-challenge.zip --output local_results_2026-11-28
python Extension4/selection_audit_2026-11-28.py --zip /path/to/small-sample-classification-challenge.zip --results local_results_2026-11-28 --output local_audit_2026-11-28
```

Choose new output directory names for subsequent runs. The experiment recreates the private row-ID input needed by the audit. Scientific result filenames retain the original protocol date. Original AUCs are archived, not newly estimated on 28 November; the post-hoc audit adds 75 set comparisons without fitting models.

To rebuild the Word report and speaker notes from the shipped, verified aggregates, first archive the existing `Extension4/deliverables_2026-11-28` and `presentation_2026-11-28` directories (the builder uses fixed filenames), then:

```bash
python -m pip install python-docx==1.2.0
python Extension4/build_revision_2026-11-28.py
```

The two DOCX files can be exported with Microsoft Word or LibreOffice. Install a Chinese-capable font (the document requests Arial Unicode MS) and visually inspect formulas and all pages after conversion. The shipped PDFs were already reviewed. The original review_checks script expects a private audit inside Extension4/results_2026-11-25_v2; use the newer audit with explicit paths above for a fresh run. No scripts automatically submit to Kaggle.
