"""Build the revised two-page report and Chinese presentation notes.

Requires python-docx. Run selection_audit_2026-11-28.py first. Render the DOCX
files with the documents skill renderer to create and inspect the final PDFs.
"""
import csv
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET

from docx import Document
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Mm, Pt, RGBColor

BASE = Path(__file__).resolve().parent
OUT = BASE / "deliverables_2026-11-28"
PRESENTATION = BASE.parent / "presentation_2026-11-28"
OUT.mkdir(exist_ok=True)
AUDIT = json.loads((BASE / "audit_2026-11-28/audit_summary_2026-11-28.json").read_text())
assert AUDIT["identical_sets"] == 75 and AUDIT["model_fits_performed"] == 0
assert AUDIT["summaries"][0]["feature49_selected_count"] == 6
with (BASE / "results_2026-11-25_v2/summary_2026-11-25.csv").open() as stream:
    SUMMARY = list(csv.DictReader(stream))


def font(style, size, chinese=False):
    style.font.name = "Arial"
    style.font.size = Pt(size)
    style.font.color.rgb = RGBColor(0, 0, 0)
    rf = style.element.get_or_add_rPr().get_or_add_rFonts()
    for attr in ("asciiTheme", "eastAsiaTheme", "hAnsiTheme", "cstheme"):
        rf.attrib.pop(qn("w:" + attr), None)
    rf.set(qn("w:eastAsia"), "Arial Unicode MS" if chinese else "Arial")


def document(chinese=False):
    doc = Document()
    section = doc.sections[0]
    section.page_width, section.page_height = Mm(210), Mm(297)
    section.top_margin, section.bottom_margin = Mm(15), Mm(15)
    section.left_margin, section.right_margin = Mm(18), Mm(18)
    section.header_distance, section.footer_distance = Mm(7), Mm(7)
    normal = doc.styles["Normal"]
    font(normal, 10.5 if chinese else 10, chinese)
    normal.paragraph_format.space_after = Pt(5)
    normal.paragraph_format.line_spacing = 1.12 if chinese else 1.08
    for name, size in [("Title", 19), ("Subtitle", 10), ("Heading 1", 12), ("Heading 2", 10.5)]:
        font(doc.styles[name], size, chinese)
        doc.styles[name].paragraph_format.space_after = Pt(5)
        doc.styles[name].paragraph_format.space_before = Pt(7 if "Heading" in name else 0)
    doc.styles["Title"].paragraph_format.keep_with_next = True
    doc.styles["Subtitle"].paragraph_format.keep_with_next = True
    for style in doc.styles:
        for border in style.element.xpath(".//w:pBdr"):
            border.getparent().remove(border)
    foot = section.footer.paragraphs[0]
    foot.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    run = foot.add_run("DSAI4203  |  Extension 4  |  ")
    run.font.size = Pt(8)
    field = OxmlElement("w:fldSimple")
    field.set(qn("w:instr"), "PAGE")
    foot._p.append(field)
    doc.core_properties.author = "Cao Wei"
    doc.core_properties.subject = "Extension 4 feature selection stability"
    return doc


def rich(doc, text, style=None, size=None, after=None):
    paragraph = doc.add_paragraph(style=style)
    root = ET.fromstring("<root>" + text + "</root>")
    def add(value, tag=None):
        if value:
            run = paragraph.add_run(value)
            run.bold = tag == "b"
            run.italic = tag == "i"
            run.font.superscript = tag == "sup"
            if size:
                run.font.size = Pt(size)
    add(root.text)
    for child in root:
        add(child.text, child.tag)
        add(child.tail)
    if after is not None:
        paragraph.paragraph_format.space_after = Pt(after)
    return paragraph


def table(doc, rows, widths):
    t = doc.add_table(rows=0, cols=len(widths))
    t.autofit = False
    for col, width in zip(t.columns, widths):
        col.width = Mm(width)
    for i, row in enumerate(rows):
        cells = t.add_row().cells
        for j, (cell, value, width) in enumerate(zip(cells, row, widths)):
            cell.width = Mm(width)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            prop = cell._tc.get_or_add_tcPr()
            margins = OxmlElement("w:tcMar")
            for edge, amount in [("top", "65"), ("bottom", "65"), ("left", "75"), ("right", "75")]:
                item = OxmlElement("w:" + edge)
                item.set(qn("w:w"), amount)
                item.set(qn("w:type"), "dxa")
                margins.append(item)
            prop.append(margins)
            borders = OxmlElement("w:tcBorders")
            for edge in ["top", "left", "bottom", "right"]:
                item = OxmlElement("w:" + edge)
                item.set(qn("w:val"), "single")
                item.set(qn("w:sz"), "4")
                item.set(qn("w:color"), "D9D9D9")
                borders.append(item)
            prop.append(borders)
            shade = OxmlElement("w:shd")
            shade.set(qn("w:fill"), "173F59" if i == 0 else ("F0F5F7" if i % 2 else "FFFFFF"))
            prop.append(shade)
            p = cell.paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.LEFT if j == 0 else WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.space_after = Pt(0)
            p.paragraph_format.line_spacing = 1
            r = p.add_run(str(value))
            r.font.size = Pt(8.6)
            r.bold = i == 0
            if i == 0:
                r.font.color.rgb = RGBColor(255, 255, 255)
        trpr = t.rows[-1]._tr.get_or_add_trPr()
        trpr.append(OxmlElement("w:cantSplit"))
        if i == 0:
            trpr.append(OxmlElement("w:tblHeader"))
    return t


def save_text(doc, path):
    parts = []
    for child in doc.element.body:
        if child.tag == qn("w:p"):
            parts.append("".join(child.xpath(".//w:t/text()")))
        elif child.tag == qn("w:tbl"):
            for row in child.xpath("./w:tr"):
                parts.append(" | ".join("".join(cell.xpath(".//w:t/text()")) for cell in row.xpath("./w:tc")))
    path.write_text("\n\n".join(parts) + "\n", encoding="utf-8")


report = document()
report.add_paragraph("Individual Extension 4\nStability of the feature ranking", "Title")
report.add_paragraph("Cao Wei  |  DSAI4203  |  Revised 28 November 2026", "Subtitle")
report.add_heading("Question", level=1)
rich(report, "How stable are absolute Pearson correlation rankings in a dataset with 250 rows and 150 features? Do stable subsets help prediction, and does bootstrap selection change which features are retained when their number is held constant?")
report.add_heading("Protocol", level=1)
rich(report, "Let <i>k</i> be the number of features retained per resample. For <i>k</i> = 10, 30 and 50, draw 1,000 bootstrap samples of 250 rows with replacement, recompute absolute Pearson correlations with the target, and record top-<i>k</i> inclusion frequencies. All settings share resamples (seed 20261125). The <i>k</i>/150 reference is not a significance threshold.")
rich(report, "Sort frequencies decreasingly and retain the prefix ending at the largest adjacent drop. Tied drops use the smaller prefix; tied feature scores use original column order. If all drops are zero, retain all features. This prespecified heuristic does not prove a distinct feature group. Full-data curves are descriptive only.")
rich(report, "Prediction uses five repeats of stratified five-fold CV (seed 420304). Within each 200-row training fold, repeat the 1,000-sample bootstrap, select features, and fit scaling and the classifier; the 50 validation rows do not enter these steps. All methods share splits. Report mean AUC, sample SD and range across the five repeat-level mean fold AUCs. Repeats reuse data and are not independent tests.")
rich(report, "Models are fixed: L2 logistic regression (LR; C = 1, lbfgs, max_iter = 10000, seed 42) and supplementary QDA (reg_param = 10<sup>-6</sup>, tol = 10<sup>-10</sup>). All-feature QDA failed under the original installed configuration before predictive scores were obtained. The documented 25 November amendment added LR for the complete all-feature comparison; all-feature QDA remains unavailable.")
rich(report, "On 28 November, a post-hoc audit compared archived selected sets with ordinary Pearson sets of the same size and counted inclusion across training folds. It used training rows only for each Pearson ranking and performed no new model fits or AUC estimation.")
report.add_heading("Results", level=1)
p = report.add_paragraph()
p.paragraph_format.space_after = Pt(3)
p.add_run().add_picture(str(BASE / "deliverables_2026-11-25/feature_frequency_2026-11-25.png"), width=Mm(174))
rich(report, "Figure 1. Full-data frequencies, sorted separately for each <i>k</i>. All largest drops occur after eight features. Boundary pairs are 0.661/0.299, 0.955/0.778 and 0.985/0.903; gaps are 0.362, 0.177 and 0.082. Separation weakens as <i>k</i> increases.", size=8.4)
rich(report, "The full-data set is {17, 46, 49, 77, 80, 98, 100, 112}. For <i>k</i> = 10, seven features {17, 46, 77, 80, 98, 100, 112} appear in all 25 training-fold sets; feature 49 appears in only 6. Selected sizes are 7 in 19 folds, 8 in five and 9 in one. Thus, the full-data eight-feature boundary contains a more consistently selected seven-feature core. These are dependent fold counts, not inclusion probabilities for new datasets.")

report.add_page_break()
report.add_heading("Results continued", level=1)
rows = [["Classifier and features", "Count", "Mean AUC", "SD", "Repeat range"]]
labels = {"all150": "All features", "pearson30": "Pearson top 30", "stable_top10": "Stable k = 10", "stable_top30": "Stable k = 30", "stable_top50": "Stable k = 50"}
for row in SUMMARY:
    family, variant = row["model"].split("_", 1)
    count = row["feature_min"] if row["feature_min"] == row["feature_max"] else row["feature_min"] + "-" + row["feature_max"]
    rows.append([family + " / " + labels[variant], count, f"{float(row['mean_auc']):.4f}", f"{float(row['repeat_sd']):.4f}", f"{float(row['repeat_min']):.4f}-{float(row['repeat_max']):.4f}"])
rows.append(["QDA / All features", "150", "Unavailable", "-", "Fit failure"])
table(report, rows, [66, 18, 26, 20, 44])
rich(report, "Table 1. Original 25 November fixed-model CV results, unchanged by this revision. Counts vary by training fold. SD describes five repeat-level means; it is not a standard error or confidence interval.", size=8.4)
rich(report, "For LR, all features score 0.7556, ordinary Pearson top 30 scores 0.8181, and stable subsets score 0.8416-0.8589. Stable <i>k</i> = 10 gains 0.1033 over all-feature LR on average (paired repeat range 0.0822-0.1240; all five gains positive). For QDA, ordinary top 30 scores 0.9944, above every stable-subset mean (0.9755-0.9892). These are fixed-model CV estimates, not nested-search or Kaggle scores.")
rich(report, "<b>Same-size feature identity.</b> Let <i>m</i> be the number selected by bootstrap in a given training fold. Recompute ordinary absolute Pearson rankings on that fold and take the first <i>m</i> features. The resulting set equals the archived stable set in 25/25 folds for each <i>k</i>, or 75/75 checks overall. Equality refers to membership, not necessarily feature order. This establishes that the observed method retained no different features from Pearson at the same count; it does not measure a new AUC gain.")
rich(report, "Because <i>m</i> still comes from bootstrap, this audit is conditional on its chosen count. It does not test whether bootstrap chooses the count better than a method that chooses it without bootstrap. The observed LR gain therefore cannot be attributed to superior feature identities at fixed size. A future comparison would select the Pearson count inside the outer training fold, with any tuning confined to inner validation.")
rich(report, "<b>Boundary sensitivity across settings.</b> Feature 49 is retained in 6/25 folds at <i>k</i> = 10, 20/25 at <i>k</i> = 30 and 25/25 at <i>k</i> = 50. The other seven full-data features appear in every fold under all three settings. This shows how the boundary feature depends on the selection setting; the full-data eight-feature set was never imposed on validation folds.")
report.add_heading("Conclusion", level=1)
rich(report, "The full-data plots identify an eight-feature boundary, while fold-local selection reveals seven consistently retained features and a setting-sensitive eighth. The stable subsets improve this fixed LR configuration relative to all features, but underperform top-30 QDA. Bootstrap supplies stability descriptions and a rule for choosing how many features to retain; the audit shows identical feature membership to ordinary Pearson when that number is held constant.")
rich(report, "Limits remain: the cutoff is heuristic, training folds overlap, the audit is post hoc, and the count-selection rule has no independent comparator. Adaptive reuse of 250 rows limits generalization. No untouched test set or new leaderboard evaluation was used. Less-stable features may help QDA through covariance information, but that mechanism was not tested.")
rich(report, "Reproducibility: original feature_stability_2026-11-25_v2.py and archived CSVs; new selection_audit_2026-11-28.py and audit outputs. Original environment: Python 3.12, scikit-learn 1.9.1. Shared project with Ron; this individual extension is for Cao Wei. OpenAI Codex assisted with design, implementation, execution, analysis and drafting.", size=8.3)
report.save(OUT / "Extension4_Report_2026-11-28.docx")
save_text(report, OUT / "report_text_2026-11-28.txt")

speech = document(chinese=True)
speech.add_paragraph("曹伟逐页讲稿与答辩说明", "Title")
speech.add_paragraph("DSAI4203  |  2026-11-28  |  v3", "Subtitle")
rich(speech, "第1至4页计划用时约2分20秒。时间为排练目标，需要本人连贯计时；只读“口播稿”，答辩说明不计入五分钟主讲。新版补充第3、4页的两项发现。")
scripts = [
    ("第1页 Small sample Classification", "15秒", "大家好，我是曹伟，另一位组员是Ron。我们用250条训练样本和150个特征做分类预测，重点研究特征选择的稳定性，以及验证结果的可靠性。"),
    ("第2页 Model and Evaluation", "30秒", "最终流程是按绝对Pearson相关性选前30个特征，标准化后训练QDA，筛选和标准化都在训练折内完成。选模、嵌套验证和归档公开榜AUC，分别约为0.997、0.994和0.992，来自不同评价过程。下面介绍我的扩展：特征排名稳定性。"),
    ("第3页 Feature Stability", "45秒", "换一批样本，选出的特征还一样吗？我对250行数据做了1,000次有放回抽样，统计特征进入前10、30和50名的频率。三种设置的最大落差都在第8个特征之后。预测时，我在训练折内重新筛选。进一步核对发现，k等于10时，7个特征在全部25折中入选，特征49只入选6次。所以，全数据的8个特征里，有7个表现得更一致。"),
    ("第4页 Stability and Prediction", "50秒", "在相同划分的重复交叉验证中，逻辑回归的AUC从全特征的约0.756提高到0.859，但QDA的稳定子集仍低于普通前30特征。新增核对显示，三种设置共75次筛选，都与普通Pearson取相同数量时的特征集合一致。bootstrap仍决定保留多少个，但不能把提升归因于相同数量下挑出了更好的特征。稳定性也不保证预测最优。下面交给Ron。"),
]
for title, duration, content in scripts:
    speech.add_heading(title, level=1)
    rich(speech, "口播稿  目标用时" + duration, size=9, after=3)
    rich(speech, content)
rich(speech, "翻页提示：第3页先解释全数据曲线，再补充折内7个核心特征；第4页先讲预测结果，再讲同数量集合核对。75次不是75个独立实验，6/25也不是1,000次bootstrap中的入选频率。", size=9)

speech.add_page_break()
speech.add_heading("数字核对与新增发现", level=1)
rich(speech, "本页用于答辩准备，不逐项朗读。原始预测结果来自2026-11-25；两项补充核对完成于2026-11-28，属于事后分析。")
speech.add_heading("同数量下是否选出了不同特征", level=2)
rich(speech, "用m表示某一训练折中bootstrap最终保留的特征数。只使用该折200条训练数据重算绝对Pearson排名，并取前m个，与保存的稳定子集比较成员。k等于10、30、50时分别为25/25折完全一致，合计75/75。比较的是集合，不要求列顺序相同。")
rich(speech, "可以说：“相同数量下，两种方法在这些折中保留了相同特征。”不能说：“普通Pearson完全替代了bootstrap”或“已经重新训练并证明AUC相同”。m仍取自bootstrap，因此没有独立检验它是否更会选择保留数量。")
speech.add_heading("8个全数据特征与7个一致入选特征", level=2)
rich(speech, "全数据选出的8个特征是17、46、49、77、80、98、100、112。去掉49后的7个，在三种k设置的全部训练折中都入选。特征49在k等于10时入选6/25折，在k等于30时为20/25，在k等于50时为25/25。")
rich(speech, "k等于10时，19折保留7个、5折保留8个、1折保留9个。特征49的全数据bootstrap前10入选频率为0.661；这与6/25衡量不同层次：前者是全数据1,000次重采样的排名频率，后者是25个训练折经过最大落差规则后的最终入选次数。")
speech.add_heading("预测分数及误差含义", level=2)
rich(speech, "第2页：Selection CV 0.99676；Nested-search CV 0.99435；Public AUC 0.99241，公开榜归档日期为2026-11-23。这三个数来自不同评价过程，不是连续提升的三个成绩，也不是准确率。")
rich(speech, "第4页：LR全部150特征为0.7556，SD为0.0190；普通Pearson前30为0.8181；稳定k等于10为0.8589，SD为0.0047。后者相对全特征的配对平均增益为0.1033，五次重复都为正。这是AUC绝对差，不能说准确率提高10.33%。")
rich(speech, "QDA普通前30为0.9944；三种稳定方案均值为0.9755至0.9892。该范围不是误差区间。SD是在五个重复的平均折AUC之间计算，不是25个折分数的SD、标准误或置信区间。训练折相互重叠，不据此宣称统计显著。")
speech.add_heading("避免信息泄漏", level=2)
rich(speech, "全数据描述每次bootstrap抽250行；预测评价每个训练折只有200行，因此折内每次抽200行。验证折50行不参与筛选或标准化。新核对也只用训练行重算Pearson；没有把全数据选出的8个特征固定用于交叉验证。")

speech.add_page_break()
speech.add_heading("答辩问题与代码状态", level=1)
qa = [
    ("bootstrap还有什么价值", "它量化重采样下的入选稳定性，并通过最大落差给出保留数量。本次核对只表明相同数量时的特征成员相同；尚未证明这套数量选择规则优于不使用bootstrap的方法。下一步如要检验，应在外层训练折内部为普通Pearson选择数量，调参只使用内层验证。"),
    ("之前说8个稳定特征现在为什么说7个", "8个对应全数据曲线的最大落差边界；7个对应训练数据发生变化后仍始终入选的成员。特征49位于边界，在较严格的k等于10设置下只入选6折。两者对应不同分析层次，不是计算矛盾，也不是说特征49没有预测价值。"),
    ("为什么使用逻辑回归进行完整比较", "固定配置的全150维QDA在原实验环境下拟合失败。原实验在取得预测分数前记录方案修订，采用固定LR完成全部特征与子集对照，并保留QDA作为补充。这不意味着所有正则化QDA方法都不能处理该问题。"),
    ("为什么QDA可能需要较不稳定的特征", "这些特征可能提供类别协方差信息，但本实验没有检验该机制。能确认的是：当前QDA普通前30的平均AUC高于三个稳定子集方案。"),
    ("代码是否进行了修改", "原始feature_stability_2026-11-25_v2.py及归档结果没有改动。本次新增selection_audit_2026-11-28.py，读取原数据和保存的折内集合，重算Pearson排名、核对75次集合、统计特征入选次数，并验证输入哈希及原AUC汇总。另新增文档构建脚本。没有重新训练模型，没有新增AUC或Kaggle提交。"),
    ("这些检查证明了什么", "核对支持数据一致、行隔离、集合相同及计数正确；不能代替独立测试集，也不能证明bootstrap选数量更优。75次是三种设置乘25折；这些训练折重叠，结果是描述性核对。"),
]
for question, answer in qa:
    speech.add_heading(question, level=2)
    rich(speech, answer)
speech.add_heading("第9页代码证据的口播边界", level=2)
rich(speech, "现有第9页展示原实验的训练折内bootstrap流程及旧检查。本次没有修改Canva页面，不能把新核对说成已显示在旧截图中。若被问到新增发现，应打开selection_audit_2026-11-28.py及audit_summary_2026-11-28.json，说明它们是独立补充核对。")
rich(speech, "共同模型项目由曹伟与Ron合作；本扩展为曹伟准备。Codex辅助设计、实现、运行、分析和起草。新版仅更新曹伟讲稿及扩展报告；Ron稿件与原演示页面保持原样。", size=9)
speech.save(PRESENTATION / "曹伟逐页讲稿_2026-11-28_v3.docx")
save_text(speech, PRESENTATION / "曹伟逐页讲稿_2026-11-28_v3.txt")
print("Built", OUT / "Extension4_Report_2026-11-28.docx")
print("Built", PRESENTATION / "曹伟逐页讲稿_2026-11-28_v3.docx")
print("Spoken Chinese characters:", sum(len(re.findall(r"[\u4e00-\u9fff]", content)) for _, _, content in scripts))
