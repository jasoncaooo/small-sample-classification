from pathlib import Path
import csv,json,importlib.util
import numpy as np
p=Path(__file__).parent;r=p/'results_2026-11-25_v2'
spec=importlib.util.spec_from_file_location('e',p/'feature_stability_2026-11-25_v2.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
rng=np.random.default_rng(10);X=rng.normal(size=(40,150));y=np.arange(40)%2
assert np.allclose(m.correlation(X,y),np.abs(np.corrcoef(np.column_stack([X,y]),rowvar=False)[-1,:150]))
f=m.bootstrap(X,y,100,17);assert np.array_equal(f,m.bootstrap(X,y,100,17))
assert np.allclose(f.sum(axis=1),[10,30,50])
assert len(m.cut(np.ones(150))[0])==150
assert set(m.cut(np.array([.8,.8,.1,.1]))[0])=={0,1}
a=list(csv.DictReader((r/'selection_audit_private_2026-11-25.csv').open()))
for row in a:
 tr=set(row['train_ids'].split(';'));va=set(row['validation_ids'].split(';'));assert len(tr)==200 and len(va)==50 and not tr&va
fr=list(csv.DictReader((r/'frequencies_2026-11-25.csv').open()))
for k in [10,30,50]:assert np.isclose(sum(float(x['frequency']) for x in fr if int(x['top_count'])==k),k)
scores=list(csv.DictReader((r/'fold_scores_2026-11-25.csv').open())); assert len(scores)==225
assert not json.loads((r/'warnings_2026-11-25.json').read_text())
rep=list(csv.DictReader((r/'repeat_scores_2026-11-25.csv').open())); lookup={(x['model'],int(x['repeat'])):float(x['mean_fold_auc']) for x in rep}
paired=[]
for family,ref in [('LR','all150'),('QDA','pearson30')]:
 for k in [10,30,50]:
  vals=[lookup[(family+'_stable_top'+str(k),i)]-lookup[(family+'_'+ref,i)] for i in range(1,6)]
  paired.append({'comparison':f'{family}_stable_top{k} minus {family}_{ref}','mean':float(np.mean(vals)),'minimum':min(vals),'maximum':max(vals)})
(r/'paired_differences_2026-11-25.json').write_text(json.dumps(paired,indent=2))
print(json.dumps(paired,indent=2));print('PASS: independent correlation check, deterministic resampling, frequency mass, cutoff edge cases, row isolation, all outputs, zero warnings.')
