from pathlib import Path
import csv,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Image,Table,TableStyle,PageBreak
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
import fitz
p=Path(__file__).parent;r=p/'results_2026-11-25_v2';out=p/'deliverables_2026-11-25';out.mkdir(exist_ok=True)
fr=list(csv.DictReader((r/'frequencies_2026-11-25.csv').open()));summary=list(csv.DictReader((r/'summary_2026-11-25.csv').open()))
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
fig,axes=plt.subplots(1,3,figsize=(10.8,3.0),sharey=True)
for ax,k in zip(axes,[10,30,50]):
 v=sorted([float(x['frequency']) for x in fr if int(x['top_count'])==k],reverse=True)
 ax.plot(range(1,151),v,color='#175f91',lw=1.8);ax.axhline(k/150,color='#8a6f45',ls='--',lw=1,label='k/150 reference');ax.axvline(8,color='#9a3939',ls=':',lw=1)
 ax.set(title=f'Top {k} per resample',xlabel='Feature position (sorted)',xlim=(1,150),ylim=(0,1.04));ax.set_xticks([1,50,100,150]);ax.text(13,.95,'cut: 8',color='#9a3939',fontsize=9)
axes[0].set_ylabel('Selection frequency');axes[2].legend(loc='center right',fontsize=8,frameon=False)
fig.tight_layout();fig.savefig(out/'feature_frequency_2026-11-25.png',dpi=220);plt.close(fig)
styles=getSampleStyleSheet();styles.add(ParagraphStyle(name='BodyX',fontName='Helvetica',fontSize=10,leading=13,spaceAfter=7));styles.add(ParagraphStyle(name='SmallX',fontName='Helvetica',fontSize=8.5,leading=11,spaceAfter=5))
styles['Title'].fontSize=19;styles['Title'].leading=23;styles['Heading2'].fontSize=12;styles['Heading2'].spaceBefore=8;styles['Heading2'].spaceAfter=6
story=[];md=[]
def para(t,style='BodyX'):story.append(Paragraph(t,styles[style]));md.append(t)
def heading(t):para(t,'Heading2')
para('Individual Extension 4<br/>Stability of the feature ranking','Title');para('Cao Wei | DSAI4203 | 25 November 2026','SmallX')
heading('Question')
para('How stable are absolute-correlation feature rankings in a 250-row, 150-feature classification dataset? Does a sharp frequency drop identify a subset worth keeping for prediction, and does that conclusion depend on the classifier?')
heading('Protocol')
para('Let k denote the number of features retained in each resample (not the number of CV folds). For k = 10, 30 and 50, use 1,000 bootstrap resamples, each containing 250 rows drawn with replacement. Recompute absolute Pearson correlations with the target and count each feature\'s top-k inclusion frequency. Use identical resamples across k; seed 20261125. The k/150 line is an exchangeable-selection reference, not a significance threshold for this structured dataset.')
para('Sort frequencies decreasingly and retain the prefix above the largest adjacent drop; ties use the smaller prefix, and feature ties use original index. If all drops are zero, retain all features. This prespecified heuristic finds a boundary but does not prove a distinct feature group. The full-data curves below are descriptive only.')
para('Predictive evaluation uses stratified five-fold CV repeated five times (seed 420304). In every fold, redo 1,000 bootstrap draws on the 200 training rows, determine the subset, and fit scaling and the classifier using training rows only. Compare all 150 features, ordinary top-30 correlation filtering, and the three stable-subset rules on identical folds. Report the mean of five repeat-level mean AUCs, their sample SD and range; the repeats reuse data and are not independent tests.')
para('Primary classifier: fixed L2 logistic regression (LR), C = 1, lbfgs, max_iter = 10000, seed 42. Supplement: fixed QDA, reg_param = 10<super>-6</super>, tol = 10<super>-10</super>. Initial all-feature QDA failed before any predictive scores: 110 class-0 training rows could not support 150 features under the installed SVD implementation. The documented protocol amendment added LR for the complete all-feature comparison; all-feature QDA remains unavailable. No predictive-result tuning followed.')
heading('Results')
story.append(Image(str(out/'feature_frequency_2026-11-25.png'),width=495,height=137.5))
para('Figure 1. All 150 features, sorted separately in each panel. The largest drop occurs after eight features for every k. The frequency pairs across the boundary are 0.661/0.299, 0.955/0.778 and 0.985/0.903, giving gaps of 0.362, 0.177 and 0.082. The boundary position is unchanged, but separation weakens as k increases.','SmallX')
story.append(PageBreak())
heading('Results (continued)')
para('The full-data stable set is {17, 46, 49, 77, 80, 98, 100, 112}, using original column identifiers. In training-fold evaluations the chosen set size varies; the eight full-data features were never imposed on validation folds.')
rows=[['Classifier / features','Count across folds','Mean AUC','SD*','Repeat range']]
labels={'all150':'All features','pearson30':'Correlation top 30','stable_top10':'Stable (k = 10)','stable_top30':'Stable (k = 30)','stable_top50':'Stable (k = 50)'}
for x in summary:
 family,variant=x['model'].split('_',1);lo=x['feature_min'];hi=x['feature_max'];rows.append([family+' / '+labels[variant],lo if lo==hi else lo+'-'+hi,f"{float(x['mean_auc']):.4f}",f"{float(x['repeat_sd']):.4f}",f"{float(x['repeat_min']):.4f}-{float(x['repeat_max']):.4f}"])
rows.append(['QDA / All features','150','Unavailable','-','Rank failure'])
t=Table(rows,colWidths=[178,102,65,49,101],repeatRows=1);t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#173f59')),('TEXTCOLOR',(0,0),(-1,0),colors.white),('FONTNAME',(0,0),(-1,0),'Helvetica-Bold'),('FONTSIZE',(0,0),(-1,-1),8.5),('BOTTOMPADDING',(0,0),(-1,-1),7),('TOPPADDING',(0,0),(-1,-1),7),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.HexColor('#f0f5f7'),colors.white]),('VALIGN',(0,0),(-1,-1),'MIDDLE')]))
story.append(t);story.append(Spacer(1,7));para('Table 1. Fixed-model, matched-split results. *SD is across five repeat-level mean fold AUCs, not a standard error or confidence interval. Counts describe fold-local selected sets.','SmallX')
para('Against all-feature LR (0.7556), all stable-subset rules improve mean AUC (0.8416-0.8589). For k = 10, the paired repeat-level gain is +0.1033, with range +0.0822 to +0.1240; the gain is positive in all five repeats. This comparison supports the usefulness of the retained subset for this fixed LR configuration.')
para('For QDA, ordinary top-30 filtering scores 0.9944, above every stable-subset mean (0.9755-0.9892). Stable k = 30 is lower by 0.0091 on average, and lower in all five repeats. Stable k = 50 is lower by 0.0052 on average, although one repeat slightly favors it. These are fresh fixed-model CV estimates, not the earlier nested-search or Kaggle scores.')
heading('Conclusion')
para('Eight features form a conspicuous stable marginal-correlation core in the full-data bootstrap plots; the largest-gap location persists across k, while the gap shrinks. The retained subsets help LR relative to all 150 features, but do not match top-30 QDA. Stability is therefore useful evidence about repeatable marginal association, not a guarantee of maximal predictive value. Less-stable features may contribute class-specific covariance information; this is a plausible explanation, not a tested mechanism.')
para('Limitations: the largest-gap rule is heuristic; the reported gain does not isolate bootstrap stability from simply reducing feature count, because there is no size-matched non-bootstrap control. Small samples and adaptive reuse of this dataset limit generalization. No private-test or new leaderboard evaluation was used, and no universal superiority is claimed.')
para('Reproducibility and disclosure: feature_stability_2026-11-25_v2.py; protocol and amendment dated 2026-11-25; aggregate CSVs and checks accompany this report. Python 3.12; scikit-learn 1.9.1. Shared project with Ron; this extension is prepared for Cao Wei. OpenAI Codex assisted with experimental design, implementation, execution, analysis and drafting.','SmallX')
def footer(c,d):c.setFont('Helvetica',8);c.setFillColor(colors.HexColor('#657582'));c.drawString(50,25,'DSAI4203 | Individual Extension 4');c.drawRightString(545,25,str(d.page))
pdf=out/'Extension4_Report_2026-11-25.pdf';SimpleDocTemplate(str(pdf),pagesize=(595,842),leftMargin=50,rightMargin=50,topMargin=35,bottomMargin=40).build(story,onFirstPage=footer,onLaterPages=footer)
(out/'report_text_2026-11-25.txt').write_text('\n\n'.join(md)+'\n\n'+ '\n'.join(' | '.join(x) for x in rows))
doc=fitz.open(pdf);print('Pages:',len(doc));assert len(doc)==2
for i,page in enumerate(doc):page.get_pixmap(matrix=fitz.Matrix(1.4,1.4)).save(out/f'preview_page_{i+1}_2026-11-25.png')
